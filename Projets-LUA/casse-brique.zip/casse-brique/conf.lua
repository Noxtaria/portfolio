require('constants')

function love.conf(t)

  t.window.title = "Casse-briques" -- Change le titre de la fenêtre
  t.window.icon = "images/icon.png" -- Change l'icone de la fenêtre
  t.window.width = 1080 -- Change la largeur de la fenêtre
  t.window.height = 840 -- Change la hauteur de la fenêtre

end