TITLE = "Casse-briques" -- Titre
PATH_ICON = "images/icon.png" -- Chemin image icône
WIN_WIDTH = 680 -- Largeur fenêtre
WIN_HEIGHT = 640 -- Hauteur fenêtre